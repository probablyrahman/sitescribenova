# SiteScribeNova AI — Website Copy Generator

A beginner-friendly hackathon MVP built with React + Vite and an Express backend. It generates Home, About, Services, FAQs, and SEO metadata; supports editable output, section tabs, copy actions, Copy All, Markdown export, regeneration, validation, loading and errors. It works in demo mode without credentials, and switches to real Claude generation when an Anthropic API key is configured.

## Requirements

- Node.js 20+ (Node.js 18.18+ may work with current Vite; Node 20+ is recommended)
- npm
- Optional: an Anthropic API key for real AI generation

## Run locally

1. Open Terminal and enter the project folder:
   ```bash
   cd sitescribenova-ai
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start both the Express backend and Vite frontend:
   ```bash
   npm run dev
   ```
4. Open **http://localhost:5173**.

The app works immediately in **demo mode** without a key. To use Claude, create a local `.env` file in the project root (copy `.env.example`), then add your key:

```env
ANTHROPIC_API_KEY=your_real_key_here
ANTHROPIC_MODEL=claude-haiku-4-5-20251001
PORT=3001
```

Restart `npm run dev` after editing `.env`. Never put the key in `client/`, a `VITE_` variable, screenshots, or GitHub. The key is only read by the Express server. Check https://docs.anthropic.com/en/api/messages for current API/model availability; if the default model alias is unavailable to your account, set `ANTHROPIC_MODEL` to a model you have access to.

## Production build

```bash
npm run build
npm start
```

Then open **http://localhost:3001**. The Express server serves the built frontend and `/api/generate`.

## Demo checklist

- Submit the form empty and confirm helpful validation appears.
- Fill all required fields and generate content.
- Confirm the demo-mode label is visible without an API key.
- Switch between all five tabs and edit the generated copy.
- Test Copy section, Copy all, Export .md, and Regenerate.
- On mobile, test the menu and responsive layout.
- If using Claude live, configure `.env`, restart the server, generate again, and confirm the mode says Claude AI generated.

## Project structure

```text
sitescribenova-ai/
├── client/
│   ├── index.html
│   ├── vite.config.js
│   └── src/
│       ├── main.jsx       # React UI and interactions
│       └── styles.css     # Responsive dark SaaS styling
├── server/
│   └── index.js           # Express API + secure Claude integration + demo fallback
├── .env.example
├── .gitignore
├── package.json
└── README.md
```

## Notes

- No database, account system, or persistent server-side storage is used.
- Generated content is held in browser memory for the current session. Refreshing the page clears it.
- The browser clipboard API generally requires localhost or HTTPS.
- Demo content is templated sample output and is explicitly labelled; it is not presented as Claude output.
