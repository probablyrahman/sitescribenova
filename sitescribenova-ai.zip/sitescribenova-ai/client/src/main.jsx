import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Sparkles, ArrowRight, Copy, Check, RotateCcw, WandSparkles, FileText, Globe, Zap, ChevronDown, Menu, X, AlertCircle, CircleCheck, Download } from 'lucide-react';
import './styles.css';

const sections = [
  { id: 'home', label: 'Home page', short: 'Home', icon: Globe },
  { id: 'about', label: 'About page', short: 'About', icon: FileText },
  { id: 'services', label: 'Services', short: 'Services', icon: Zap },
  { id: 'faqs', label: 'FAQs', short: 'FAQs', icon: CircleCheck },
  { id: 'seo', label: 'SEO metadata', short: 'SEO', icon: WandSparkles },
];
const initialForm = { businessName: '', industry: '', description: '', audience: '', offerings: '', tone: 'Professional', keywords: '', cta: 'Get started today' };

function demoContent(f) {
  const name = f.businessName.trim() || 'Your Business';
  const industry = f.industry.trim() || 'your industry';
  const audience = f.audience.trim() || 'people looking for a better solution';
  const offerings = f.offerings.trim() || 'thoughtful, tailored solutions';
  const description = f.description.trim() || `${name} helps customers get more from ${industry}.`;
  const keyword = f.keywords.trim().split(',')[0]?.trim() || industry;
  const cta = f.cta.trim() || 'Get started today';
  return {
    home: `# ${name}\n\n## A smarter way to move forward.\n\nDiscover a better way to reach your goals with ${name}. ${description} We bring together practical expertise, thoughtful service, and solutions built around what matters to you.\n\n### Made for your next step\n\nWhether you are just getting started or ready to grow, our ${offerings.toLowerCase()} are designed to make the journey clearer and easier.\n\n**Ready to see what is possible?**\n\n${cta}.`,
    about: `# The story behind ${name}\n\nAt ${name}, we believe great ${industry.toLowerCase()} should feel clear, useful, and centred on people. ${description}\n\n### What drives us\n\nOur goal is to help ${audience.toLowerCase()} move forward with confidence. We listen first, focus on the details, and shape every experience around real needs—not one-size-fits-all answers.\n\n### Our approach\n\n- **People first:** Understand the person behind every request.\n- **Purposeful work:** Keep every recommendation practical and relevant.\n- **Better, together:** Build lasting relationships through care and consistency.\n\nWe are glad you are here. Let’s build something meaningful.`,
    services: `# What we can do for you\n\n${name} offers ${offerings.toLowerCase()} to help ${audience.toLowerCase()} solve real challenges and make meaningful progress.\n\n### Solutions shaped around you\n\n**Personalised guidance**\nGet recommendations shaped around your goals, priorities, and current stage.\n\n**Reliable delivery**\nExpect a considered process, clear communication, and attention to the details that matter.\n\n**Support that continues**\nMove forward with a team focused on helping you get lasting value from every step.\n\n### Let’s find your fit\n\nTell us what you are working toward and we will help you explore the right next step.\n\n**${cta}.**`,
    faqs: `# Frequently asked questions\n\n**1. What does ${name} do?**\n${name} works in ${industry.toLowerCase()}, offering ${offerings.toLowerCase()} to help customers reach their goals.\n\n**2. Who are your services for?**\nWe work with ${audience.toLowerCase()}. Get in touch to discuss your specific needs.\n\n**3. How do I get started?**\nReach out through our contact channel and tell us a little about your goals. We will help you understand the next steps.\n\n**4. Can I get a solution tailored to my needs?**\nAbsolutely. We aim to understand your situation first and recommend an approach that fits.\n\n**5. How much do your services cost?**\nPricing depends on your requirements and scope. Contact us for details relevant to your needs.\n\n**6. How long does the process take?**\nTimelines vary depending on the service and project scope. We will discuss expectations with you before work begins.\n\n**7. How can I contact your team?**\nUse our website contact form or preferred contact channel and our team will guide you from there.`,
    seo: `SEO Title: ${name} | ${industry}\n\nMeta Description: Discover ${name} for ${keyword}. Explore ${offerings.toLowerCase()} designed around your needs. ${cta}.\n\nKeywords: ${[keyword, ...f.keywords.split(',').map(s => s.trim()).filter(Boolean), industry, name].filter(Boolean).filter((v,i,a)=>a.indexOf(v)===i).join(', ')}\n\nURL Slug: ${name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}`
  };
}

function App() {
  const [form, setForm] = useState(initialForm);
  const [results, setResults] = useState(null);
  const [activeTab, setActiveTab] = useState('home');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const [mode, setMode] = useState('');
  const [mobileMenu, setMobileMenu] = useState(false);
  const [generatedAt, setGeneratedAt] = useState('');

  const update = (key, value) => setForm(prev => ({ ...prev, [key]: value }));
  const goToForm = () => document.getElementById('generator')?.scrollIntoView({ behavior: 'smooth' });
  const copyText = async (value, label = 'Section') => {
    try {
      await navigator.clipboard.writeText(value);
      setNotice(`${label} copied to clipboard`);
      setTimeout(() => setNotice(''), 2200);
    } catch {
      setNotice('Clipboard access was blocked. Select the text and copy it manually.');
      setTimeout(() => setNotice(''), 3500);
    }
  };
  const generate = async (event) => {
    event?.preventDefault();
    setError(''); setNotice('');
    const required = [['businessName', 'Business name'], ['industry', 'Industry'], ['description', 'Business description'], ['audience', 'Target audience'], ['offerings', 'Products or services']];
    const missing = required.filter(([key]) => !form[key].trim()).map(([, label]) => label);
    if (missing.length) { setError(`Please fill in: ${missing.join(', ')}.`); document.getElementById('generator')?.scrollIntoView({ behavior: 'smooth' }); return; }
    setLoading(true);
    try {
      const response = await fetch('/api/generate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
      if (!data.content || !sections.every(s => typeof data.content[s.id] === 'string' && data.content[s.id].trim())) throw new Error('The generator returned incomplete content. Please regenerate.');
      setResults(data.content); setMode(data.mode || 'demo'); setGeneratedAt(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })); setActiveTab('home');
      setNotice(data.mode === 'ai' ? 'Your copy is ready — generated with Claude.' : 'Demo copy is ready. Add an API key to generate with Claude.');
      setTimeout(() => setNotice(''), 4200);
      setTimeout(() => document.getElementById('results')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
    } catch (err) { setError(err.message || 'Could not generate copy. Please check your connection and try again.'); }
    finally { setLoading(false); }
  };
  const copyAll = () => results && copyText(sections.map(s => `===== ${s.label.toUpperCase()} =====\n\n${results[s.id]}`).join('\n\n\n'), 'All website copy');
  const downloadAll = () => {
    if (!results) return;
    const body = sections.map(s => `# ${s.label}\n\n${results[s.id]}`).join('\n\n---\n\n');
    const blob = new Blob([body], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = `${form.businessName.toLowerCase().replace(/[^a-z0-9]+/g, '-') || 'website'}-copy.md`; a.click(); URL.revokeObjectURL(url);
  };

  return <div className="app-shell">
    <div className="ambient ambient-one"/><div className="ambient ambient-two"/>
    <header className="navbar"><a className="brand" href="#top" aria-label="SiteScribeNova AI home"><span className="brand-mark"><Sparkles size={19}/></span><span>SiteScribeNova <b>AI</b></span></a>
      <nav className={mobileMenu ? 'nav-links open' : 'nav-links'}><a href="#how-it-works" onClick={() => setMobileMenu(false)}>How it works</a><a href="#generator" onClick={() => setMobileMenu(false)}>Generator</a><a href="#results" onClick={() => setMobileMenu(false)}>Your workspace</a><button className="nav-cta" onClick={() => { goToForm(); setMobileMenu(false); }}>Start creating <ArrowRight size={15}/></button></nav>
      <button className="mobile-toggle" aria-label="Toggle menu" onClick={() => setMobileMenu(!mobileMenu)}>{mobileMenu ? <X/> : <Menu/>}</button>
    </header>

    <main id="top"><section className="hero">
      <div className="hero-copy"><div className="eyebrow"><span className="eyebrow-dot"/> YOUR CREATIVE PARTNER, POWERED BY AI</div>
        <h1>Your Website.<br/>Your Story.<br/><span>Written by AI.</span></h1>
        <p className="hero-subtitle">Generate compelling website copy for your business in seconds. Less staring at a blank page. More bringing your ideas to life.</p>
        <div className="hero-actions"><button className="primary-btn" onClick={goToForm}>Start Creating <ArrowRight size={18}/></button><a className="text-link" href="#how-it-works">See how it works <span>↓</span></a></div>
        <div className="trust-row"><div className="avatar-stack"><span>M</span><span>A</span><span>J</span><span>+</span></div><div><strong>Made for your next big idea</strong><small>From first draft to launch-ready copy</small></div></div>
      </div>
      <div className="hero-visual"><div className="visual-orbit orbit-a"/><div className="visual-orbit orbit-b"/><div className="visual-glow"/><div className="preview-card"><div className="preview-top"><div className="window-dots"><i/><i/><i/></div><span className="preview-label"><span/> SITESCRIBENOVA STUDIO</span><span className="preview-menu">•••</span></div><div className="preview-body"><div className="preview-pill"><Sparkles size={12}/> AI GENERATED CONCEPT</div><div className="preview-line tiny"/><div className="preview-title">Make your next<br/><span>chapter count.</span></div><div className="preview-line wide"/><div className="preview-line medium"/><div className="preview-line short"/><div className="preview-bottom"><div className="preview-button">Explore what’s possible <ArrowRight size={13}/></div><div className="preview-art"><div className="art-ring ring-one"/><div className="art-ring ring-two"/><Sparkles size={25}/></div></div></div><div className="floating-chip chip-top"><span className="chip-icon"><WandSparkles size={17}/></span><div><b>On-brand copy</b><small>Tailored to your voice</small></div><Check size={16} className="chip-check"/></div><div className="floating-chip chip-bottom"><span className="score">98</span><div><b>SEO ready</b><small>Search-friendly content</small></div><span className="score-star">✦</span></div></div>
    </section>

    <section className="feature-strip" id="how-it-works"><div className="feature"><span className="feature-icon purple"><WandSparkles size={18}/></span><div><b>One brief, five sections</b><small>Your whole website starts here</small></div></div><div className="feature"><span className="feature-icon blue"><Zap size={18}/></span><div><b>Fast by design</b><small>Go from idea to first draft in moments</small></div></div><div className="feature"><span className="feature-icon pink"><FileText size={18}/></span><div><b>Made to be edited</b><small>Your voice. Your final say.</small></div></div></section>

    <section className="builder-section" id="generator"><div className="section-heading"><div className="eyebrow"><span className="eyebrow-dot"/> THE COPY STUDIO</div><h2>Let’s make something <span>remarkable.</span></h2><p>Tell us a little about your business. We’ll take it from there.</p></div>
      <div className="builder-layout"><form className="form-card" onSubmit={generate} noValidate><div className="card-heading"><div className="heading-icon"><FileText size={19}/></div><div><h3>Your business brief</h3><p>The more we know, the better your copy gets.</p></div><span className="step-tag">STEP 01</span></div>
        {error && <div className="alert error-alert" role="alert"><AlertCircle size={17}/><span>{error}</span></div>}
        <div className="form-grid"><label className="field full"><span>Business name <em>*</em></span><input value={form.businessName} onChange={e=>update('businessName',e.target.value)} placeholder="e.g. Bloom & Co." maxLength={100}/></label>
          <label className="field"><span>Industry <em>*</em></span><div className="select-wrap"><select value={form.industry} onChange={e=>update('industry',e.target.value)}><option value="">Choose your industry</option>{['Technology & SaaS','Health & Wellness','Food & Beverage','Fashion & Beauty','Education','Finance','Real Estate','Creative Agency','E-commerce','Professional Services','Travel & Hospitality','Fitness','Non-profit','Other'].map(v=><option key={v}>{v}</option>)}</select><ChevronDown size={16}/></div></label>
          <label className="field"><span>Writing tone</span><div className="select-wrap"><select value={form.tone} onChange={e=>update('tone',e.target.value)}>{['Professional','Friendly','Persuasive','Minimal','Playful'].map(v=><option key={v}>{v}</option>)}</select><ChevronDown size={16}/></div></label>
          <label className="field full"><span>What does your business do? <em>*</em></span><textarea rows="3" value={form.description} onChange={e=>update('description',e.target.value)} placeholder="Describe your business, what makes it special, and the problem you solve…" maxLength={1200}/><small className="field-hint">A few clear sentences work best.</small></label>
          <label className="field full"><span>Who is your target audience? <em>*</em></span><input value={form.audience} onChange={e=>update('audience',e.target.value)} placeholder="e.g. Busy professionals who value sustainable products" maxLength={400}/></label>
          <label className="field full"><span>Products or services <em>*</em></span><textarea rows="2" value={form.offerings} onChange={e=>update('offerings',e.target.value)} placeholder="What do you offer? List your key products or services…" maxLength={800}/></label>
          <label className="field full"><span>Target SEO keywords <small>(optional)</small></span><input value={form.keywords} onChange={e=>update('keywords',e.target.value)} placeholder="e.g. sustainable skincare, natural face cream" maxLength={300}/><small className="field-hint">Separate keywords with commas.</small></label>
          <label className="field full"><span>Call to action <small>(optional)</small></span><input value={form.cta} onChange={e=>update('cta',e.target.value)} placeholder="e.g. Book a free consultation" maxLength={120}/></label>
        </div>
        <div className="form-footer"><span className="required-note"><em>*</em> Required fields</span><button className="primary-btn generate-btn" type="submit" disabled={loading}>{loading ? <><span className="spinner"/> Creating your copy…</> : <><Sparkles size={17}/> Generate Website Copy <ArrowRight size={17}/></>}</button></div>
        <div className="privacy-note"><span className="privacy-dot"/> No account needed <span>·</span> Your brief isn’t saved to a database</div>
      </form>

      <aside className="side-panel"><div className="side-top"><span className="side-label">YOUR CREATIVE OUTPUT</span><span className="live-indicator"><i/> READY</span></div><h3>Everything your website needs.</h3><p>One brief, thoughtfully turned into five essential pieces of website copy.</p><div className="output-list">{sections.map((s,i)=><div className="output-item" key={s.id}><div className={`output-icon oi-${s.id}`}><s.icon size={17}/></div><div><b>{s.label}</b><small>{['A homepage that hooks your visitors','Your mission, story, and values','Clear offers that convert','Helpful answers that build trust','Titles, descriptions, and keywords'][i]}</small></div><span className="output-number">0{i+1}</span></div>)}</div><div className="side-bottom"><div className="sparkle-orb"><Sparkles size={19}/></div><div><b>Your voice, not a template.</b><p>Choose your tone and shape every draft to fit your brand.</p></div></div></aside></div>
    </section>

    <section className="results-section" id="results"><div className="section-heading results-heading"><div className="eyebrow"><span className="eyebrow-dot"/> YOUR WORKSPACE</div><h2>From brief to <span>beautiful copy.</span></h2><p>Your generated content lives here. Edit it, copy it, make it yours.</p></div>
      {!results ? <div className="empty-state"><div className="empty-art"><div className="empty-sheet sheet-back"/><div className="empty-sheet sheet-front"><Sparkles size={25}/><span/><span/><span/></div><div className="empty-star">✦</div></div><h3>Your next great draft starts here.</h3><p>Fill in your business brief above and hit <strong>Generate Website Copy</strong> to see your content appear here.</p><button className="secondary-btn" onClick={goToForm}>Build my first draft <ArrowRight size={16}/></button></div> : <div className="results-card"><div className="results-top"><div className="results-title"><div className="results-spark"><Sparkles size={19}/></div><div><h3>{form.businessName} <span className="content-ready">● READY</span></h3><p>Generated at {generatedAt} · {form.tone} tone</p></div></div><div className="result-actions"><button className="secondary-btn small-btn" onClick={downloadAll}><Download size={15}/> Export .md</button><button className="secondary-btn small-btn" onClick={copyAll}><Copy size={15}/> Copy all</button><button className="primary-btn small-btn" onClick={generate} disabled={loading}>{loading ? <span className="spinner"/> : <RotateCcw size={15}/>} Regenerate</button></div></div>
        <div className="mode-note"><span className={mode === 'ai' ? 'mode-icon ai-mode' : 'mode-icon demo-mode'}>{mode === 'ai' ? <Sparkles size={14}/> : <AlertCircle size={14}/>}</span><span>{mode === 'ai' ? 'Claude AI generated' : 'Demo mode · Sample content'}{mode !== 'ai' && ' — add your Anthropic API key to enable real AI generation.'}</span></div>
        <div className="tab-list" role="tablist" aria-label="Generated copy sections">{sections.map(s=><button key={s.id} role="tab" aria-selected={activeTab===s.id} className={`tab ${activeTab===s.id?'active':''}`} onClick={()=>setActiveTab(s.id)}><s.icon size={16}/><span>{s.short}</span></button>)}</div>
        <div className="editor-panel"><div className="editor-head"><div><span className="editor-kicker">EDIT YOUR CONTENT</span><h4>{sections.find(s=>s.id===activeTab)?.label}</h4></div><button className="copy-btn" onClick={()=>copyText(results[activeTab], sections.find(s=>s.id===activeTab)?.label)}><Copy size={15}/> Copy section</button></div><textarea aria-label={`Edit ${activeTab} content`} className="content-editor" value={results[activeTab]} onChange={e=>setResults(prev=>({...prev,[activeTab]:e.target.value}))} spellCheck="true"/><div className="editor-foot"><span><Check size={14}/> Changes are saved in this session</span><span>{results[activeTab].length.toLocaleString()} characters</span></div></div>
        <div className="results-bottom"><div><span className="bottom-spark">✦</span><span>Like the direction? Fine-tune your brief and regenerate any time.</span></div><button className="text-link" onClick={goToForm}>Edit business brief <ArrowRight size={15}/></button></div>
      </div>}
    </section>
    </main>
    <footer className="footer"><a className="brand footer-brand" href="#top"><span className="brand-mark"><Sparkles size={17}/></span><span>SiteScribeNova <b>AI</b></span></a><span>Make every word work harder.</span><span className="footer-right">Built for big ideas <span>✦</span> © 2026 SiteScribeNova AI</span></footer>
    {notice && <div className="toast" role="status"><Check size={16}/>{notice}<button aria-label="Dismiss notification" onClick={()=>setNotice('')}><X size={14}/></button></div>}
  </div>;
}

createRoot(document.getElementById('root')).render(<App/>);
