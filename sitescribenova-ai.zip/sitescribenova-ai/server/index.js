import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const app = express();
const PORT = Number(process.env.PORT || 3001);
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.use(cors());
app.use(express.json({ limit: '50kb' }));

function clean(value, max = 1200) {
  return typeof value === 'string' ? value.trim().slice(0, max) : '';
}
function demoContent(f) {
  const name = f.businessName || 'Your Business';
  const industry = f.industry || 'your industry';
  const audience = f.audience || 'people looking for a better solution';
  const offerings = f.offerings || 'thoughtful, tailored solutions';
  const description = f.description || `${name} helps customers get more from ${industry}.`;
  const keyword = f.keywords.split(',')[0]?.trim() || industry;
  const cta = f.cta || 'Get started today';
  return {
    home: `# ${name}\n\n## A smarter way to move forward.\n\nDiscover a better way to reach your goals with ${name}. ${description} We bring together practical expertise, thoughtful service, and solutions built around what matters to you.\n\n### Made for your next step\n\nWhether you are just getting started or ready to grow, our ${offerings.toLowerCase()} are designed to make the journey clearer and easier.\n\n**Ready to see what is possible?**\n\n${cta}.`,
    about: `# The story behind ${name}\n\nAt ${name}, we believe great ${industry.toLowerCase()} should feel clear, useful, and centred on people. ${description}\n\n### What drives us\n\nOur goal is to help ${audience.toLowerCase()} move forward with confidence. We listen first, focus on the details, and shape every experience around real needs—not one-size-fits-all answers.\n\n### Our approach\n\n- **People first:** Understand the person behind every request.\n- **Purposeful work:** Keep every recommendation practical and relevant.\n- **Better, together:** Build lasting relationships through care and consistency.\n\nWe are glad you are here. Let’s build something meaningful.`,
    services: `# What we can do for you\n\n${name} offers ${offerings.toLowerCase()} to help ${audience.toLowerCase()} solve real challenges and make meaningful progress.\n\n### Solutions shaped around you\n\n**Personalised guidance**\nGet recommendations shaped around your goals, priorities, and current stage.\n\n**Reliable delivery**\nExpect a considered process, clear communication, and attention to the details that matter.\n\n**Support that continues**\nMove forward with a team focused on helping you get lasting value from every step.\n\n### Let’s find your fit\n\nTell us what you are working toward and we will help you explore the right next step.\n\n**${cta}.**`,
    faqs: `# Frequently asked questions\n\n**1. What does ${name} do?**\n${name} works in ${industry.toLowerCase()}, offering ${offerings.toLowerCase()} to help customers reach their goals.\n\n**2. Who are your services for?**\nWe work with ${audience.toLowerCase()}. Get in touch to discuss your specific needs.\n\n**3. How do I get started?**\nReach out through our contact channel and tell us a little about your goals. We will help you understand the next steps.\n\n**4. Can I get a solution tailored to my needs?**\nAbsolutely. We aim to understand your situation first and recommend an approach that fits.\n\n**5. How much do your services cost?**\nPricing depends on your requirements and scope. Contact us for details relevant to your needs.\n\n**6. How long does the process take?**\nTimelines vary depending on the service and project scope. We will discuss expectations with you before work begins.\n\n**7. How can I contact your team?**\nUse our website contact form or preferred contact channel and our team will guide you from there.`,
    seo: `SEO Title: ${name} | ${industry}\n\nMeta Description: Discover ${name} for ${keyword}. Explore ${offerings.toLowerCase()} designed around your needs. ${cta}.\n\nKeywords: ${[keyword, ...f.keywords.split(',').map(s => s.trim()).filter(Boolean), industry, name].filter(Boolean).filter((v,i,a)=>a.indexOf(v)===i).join(', ')}\n\nURL Slug: ${name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '')}`
  };
}

app.get('/api/health', (_req, res) => res.json({ ok: true, mode: process.env.ANTHROPIC_API_KEY ? 'ai' : 'demo' }));
app.post('/api/generate', async (req, res) => {
  const body = req.body || {};
  const form = {
    businessName: clean(body.businessName, 100),
    industry: clean(body.industry, 100),
    description: clean(body.description, 1200),
    audience: clean(body.audience, 400),
    offerings: clean(body.offerings, 800),
    tone: ['Professional', 'Friendly', 'Persuasive', 'Minimal', 'Playful'].includes(body.tone) ? body.tone : 'Professional',
    keywords: clean(body.keywords, 300),
    cta: clean(body.cta, 120) || 'Get started today'
  };
  const missing = ['businessName', 'industry', 'description', 'audience', 'offerings'].filter(k => !form[k]);
  if (missing.length) return res.status(400).json({ error: `Please complete the required fields: ${missing.join(', ')}.` });

  // Safe demo mode: no credential is required to demonstrate the full workflow.
  if (!process.env.ANTHROPIC_API_KEY) return res.json({ mode: 'demo', content: demoContent(form) });

  try {
    const model = process.env.ANTHROPIC_MODEL || 'claude-haiku-4-5-20251001';
    const prompt = `You are a senior website copywriter and SEO specialist. Write original, useful website copy using the business brief below. Follow the requested tone. Do not invent specific awards, statistics, certifications, guarantees, testimonials, prices, or factual claims not supplied. Avoid generic filler and keyword stuffing.\n\nBUSINESS BRIEF\nBusiness name: ${form.businessName}\nIndustry: ${form.industry}\nDescription: ${form.description}\nTarget audience: ${form.audience}\nProducts/services: ${form.offerings}\nTone: ${form.tone}\nSEO keywords: ${form.keywords || 'Suggest relevant, natural keywords'}\nCall to action: ${form.cta}\n\nReturn ONLY a valid JSON object with exactly these string keys: home, about, services, faqs, seo. No markdown code fence.\n- home: polished homepage copy with headline, subheadline, value proposition, supporting copy, and CTA.\n- about: compelling about-page copy, story, mission/approach, and values without making up history.\n- services: clear service descriptions based only on the supplied brief and a CTA.\n- faqs: 5 to 8 relevant numbered FAQs with helpful answers. If the brief doesn't provide a fact (like exact pricing), say the visitor should contact the business rather than inventing it.\n- seo: SEO Title, Meta Description (aim for 140–160 characters), Keywords (comma-separated), and URL Slug on separate lines. Keep SEO title concise.\nUse readable plain text with simple headings; escape JSON correctly.`;
    const upstream = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': process.env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model, max_tokens: 3500, messages: [{ role: 'user', content: prompt }] })
    });
    const payload = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      const message = upstream.status === 401 ? 'The Anthropic API key was rejected. Check ANTHROPIC_API_KEY in your .env file.' : (payload.error?.message || `Anthropic API returned status ${upstream.status}.`);
      return res.status(502).json({ error: message });
    }
    const raw = (payload.content || []).filter(part => part.type === 'text').map(part => part.text).join('\n').trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '');
    const parsed = JSON.parse(raw);
    const keys = ['home', 'about', 'services', 'faqs', 'seo'];
    if (!parsed || keys.some(key => typeof parsed[key] !== 'string' || !parsed[key].trim())) throw new Error('The AI response did not contain all required sections. Please regenerate.');
    return res.json({ mode: 'ai', content: Object.fromEntries(keys.map(key => [key, parsed[key].trim()])) });
  } catch (error) {
    console.error('Generation failed:', error.message);
    return res.status(502).json({ error: error.message.includes('JSON') || error.message.includes('required sections') ? error.message : 'AI generation failed. Check your API key and connection, then try again.' });
  }
});

// Serve the production build when it exists; during development Vite serves the frontend.
const distPath = path.resolve(__dirname, '../client/dist');
app.use(express.static(distPath));
app.get(/.*/, (req, res, next) => {
  if (req.path.startsWith('/api/')) return next();
  res.sendFile(path.join(distPath, 'index.html'), err => { if (err) res.status(404).send('Frontend build not found. Run npm run build, or use npm run dev.'); });
});
app.listen(PORT, () => console.log(`SiteScribeNova AI server listening on http://localhost:${PORT} (${process.env.ANTHROPIC_API_KEY ? 'Claude API enabled' : 'demo mode'})`));
